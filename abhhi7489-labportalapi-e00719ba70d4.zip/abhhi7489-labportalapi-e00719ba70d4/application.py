import time
from typing import Optional

import uvicorn
from fastapi import FastAPI, Query, Header
from starlette.requests import Request
from logical import applogic
from starlette.middleware.cors import CORSMiddleware
from logical.authenticator import token_required
from logical.logger import log_request, log_response
from models import basemodel
from models.enums import AppStatus
from models.returnjson import ReturnJson
# from fastapi.middleware.cors import CORSMiddleware

application = app = FastAPI()

# Added Cors

origins = ["*"]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# mandatory to add parameters to each endpoint signature
# request: Request
# logger: str = Query(None, include_in_schema=False)
# ccmg_token: str = Header(default=None),


# lookup Route #
@app.get("/lookup")
@log_request
@token_required
async def lookup(request: Request,
                 logger: str = Query(None, include_in_schema=False),
                 ccmg_token: str = Header(default=None)):
    start_time = time.time()

    # add logic for api processing here #
    rtn = applogic.getLookups(app, params="").get()
    # end of section #

    end_time = time.time()

    rj = ReturnJson()
    rj.set_fetch_time(end_time - start_time)
    rj.set_http_status(rtn['code'])
    rj.set_result_json(rtn['object'])

    if logger.result_code == AppStatus.success:
        rj.set_request_logging_status(AppStatus.success.value)

        resp_log = log_response(rj.serialize(), logger.result_obj)
        if resp_log.result_code == AppStatus.success:
            rj.set_response_logging_status(AppStatus.success.value)
        else:
            rj.set_response_logging_status(AppStatus.logging_error.value)
    else:
        rj.set_request_logging_status(AppStatus.logging_error.value)

    resp = rj.get_json()

    return resp


# Get client logo route with client id #
@app.get("/getclientlogo/{clientid}")
@log_request
@token_required
async def getclientlogo(request: Request,
                        clientid: str,
                        logger: str = Query(None, include_in_schema=False),
                        ccmg_token: str = Header(default=None),
                        params: Optional[None] = Query(None, include_in_schema=False)
                        ):
    start_time = time.time()

    # add logic for api processing here #
    rtn = applogic.getClientLogo(app, clientid).get()
    # end of section #

    end_time = time.time()

    rj = ReturnJson()
    rj.set_fetch_time(end_time - start_time)
    rj.set_http_status(rtn['code'])
    rj.set_result_json(rtn['object'])

    if logger.result_code == AppStatus.success:
        rj.set_request_logging_status(AppStatus.success.value)

        resp_log = log_response(rj.serialize(), logger.result_obj)
        if resp_log.result_code == AppStatus.success:
            rj.set_response_logging_status(AppStatus.success.value)
        else:
            rj.set_response_logging_status(AppStatus.logging_error.value)
    else:
        rj.set_request_logging_status(AppStatus.logging_error.value)

    resp = rj.get_json()

    return resp


@app.get("/accountprojects")
@log_request
@token_required
async def get_account_projects(request: Request,
                               logger: str = Query(None, include_in_schema=False),
                               ccmg_token: str = Header(default=None)):
    start_time = time.time()

    # add logic for api processing here #
    rtn = applogic.getAccountProjects(app).get()
    # end of section #

    end_time = time.time()

    rj = ReturnJson()
    rj.set_fetch_time(end_time - start_time)
    rj.set_http_status(rtn['code'])
    rj.set_result_json(rtn['object'])

    if logger.result_code == AppStatus.success:
        rj.set_request_logging_status(AppStatus.success.value)

        resp_log = log_response(rj.serialize(), logger.result_obj)
        if resp_log.result_code == AppStatus.success:
            rj.set_response_logging_status(AppStatus.success.value)
        else:
            rj.set_response_logging_status(AppStatus.logging_error.value)
    else:
        rj.set_request_logging_status(AppStatus.logging_error.value)

    resp = rj.get_json()

    return resp


@app.get("/getstatecitylist")
@log_request
@token_required
async def get_city_state_list(request: Request,
                              logger: str = Query(None, include_in_schema=False),
                              ccmg_token: str = Header(default=None),
                              ):
    start_time = time.time()

    # add logic for api processing here #
    rtn = applogic.getStateCityList(app).get()
    # end of section #

    end_time = time.time()

    rj = ReturnJson()
    rj.set_fetch_time(end_time - start_time)
    rj.set_http_status(rtn['code'])
    rj.set_result_json(rtn['object'])

    if logger.result_code == AppStatus.success:
        rj.set_request_logging_status(AppStatus.success.value)

        resp_log = log_response(rj.serialize(), logger.result_obj)
        if resp_log.result_code == AppStatus.success:
            rj.set_response_logging_status(AppStatus.success.value)
        else:
            rj.set_response_logging_status(AppStatus.logging_error.value)
    else:
        rj.set_request_logging_status(AppStatus.logging_error.value)

    resp = rj.get_json()

    return resp


@app.post("/memberlist")
@log_request
@token_required
async def get_member_list(request: Request,
                          logger: str = Query(None, include_in_schema=False),
                          ccmg_token: str = Header(default=None),
                          params: Optional[basemodel.MembersList] = None
                          ):
    start_time = time.time()

    # add logic for api processing here #
    rtn = applogic.getMemberList(app, params).get()
    # end of section #

    end_time = time.time()

    rj = ReturnJson()
    rj.set_fetch_time(end_time - start_time)
    rj.set_http_status(rtn['code'])
    rj.set_result_json(rtn['object'])

    if logger.result_code == AppStatus.success:
        rj.set_request_logging_status(AppStatus.success.value)

        resp_log = log_response(rj.serialize(), logger.result_obj)
        if resp_log.result_code == AppStatus.success:
            rj.set_response_logging_status(AppStatus.success.value)
        else:
            rj.set_response_logging_status(AppStatus.logging_error.value)
    else:
        rj.set_request_logging_status(AppStatus.logging_error.value)

    resp = rj.get_json()
    return resp


# add new endpoint for validating orders using moleculer API need to be fixed
# @app.post("/validating")
# @log_request
# @token_required
# async def app(scope, receive, send):
#     assert scope['type'] == "https://gist.github.com/Molecular-Vancouver/d9441ad965373cd32e595ab90dec6d98.js"
#     request = Response(scope, receive)
#     content = '%s %s' % (request.method, request.url.path)
#     response = Response(content, media_type='text/plain')
#     await response(scope.scope, receive, send)
@app.get("/getmatchingpcplist")
@log_request
@token_required
async def get_matching_pcp_list(request: Request,
                                logger: str = Query(None, include_in_schema=False),
                                ccmg_token: str = Header(default=None),
                                params: Optional[str] = None
                                ):
    start_time = time.time()

    # add logic for api processing here #
    rtn = applogic.get_matching_PCP_list(app, params).get()
    # end of section #

    end_time = time.time()

    rj = ReturnJson()
    rj.set_fetch_time(end_time - start_time)
    rj.set_http_status(rtn['code'])
    rj.set_result_json(rtn['object'])

    if logger.result_code == AppStatus.success:
        rj.set_request_logging_status(AppStatus.success.value)

        resp_log = log_response(rj.serialize(), logger.result_obj)
        if resp_log.result_code == AppStatus.success:
            rj.set_response_logging_status(AppStatus.success.value)
        else:
            rj.set_response_logging_status(AppStatus.logging_error.value)
    else:
        rj.set_request_logging_status(AppStatus.logging_error.value)

    resp = rj.get_json()
    return resp


@app.get("/getvisitstatusme")
@log_request
@token_required
async def get_visit_status_me(request: Request,
                              logger: str = Query(None, include_in_schema=False),
                              ccmg_token: str = Header(default=None),
                              params: Optional[str] = None
                              ):
    start_time = time.time()

    # add logic for api processing here #
    rtn = applogic.sp_getVisitStatusME(app, params).get()
    # end of section #

    end_time = time.time()

    rj = ReturnJson()
    rj.set_fetch_time(end_time - start_time)
    rj.set_http_status(rtn['code'])
    rj.set_result_json(rtn['object'])

    if logger.result_code == AppStatus.success:
        rj.set_request_logging_status(AppStatus.success.value)

        resp_log = log_response(rj.serialize(), logger.result_obj)
        if resp_log.result_code == AppStatus.success:
            rj.set_response_logging_status(AppStatus.success.value)
        else:
            rj.set_response_logging_status(AppStatus.logging_error.value)
    else:
        rj.set_request_logging_status(AppStatus.logging_error.value)

    resp = rj.get_json()
    return resp


@app.get("/physicianworkload")
@log_request
@token_required
async def physician_work_load(request: Request,
                              logger: str = Query(None, include_in_schema=False),
                              ccmg_token: str = Header(default=None)
                              ):
    start_time = time.time()

    # add logic for api processing here #
    rtn = applogic.physicianWorkLoad(app).get()
    # end of section #

    end_time = time.time()

    rj = ReturnJson()
    rj.set_fetch_time(end_time - start_time)
    rj.set_http_status(rtn['code'])
    rj.set_result_json(rtn['object'])

    if logger.result_code == AppStatus.success:
        rj.set_request_logging_status(AppStatus.success.value)

        resp_log = log_response(rj.serialize(), logger.result_obj)
        if resp_log.result_code == AppStatus.success:
            rj.set_response_logging_status(AppStatus.success.value)
        else:
            rj.set_response_logging_status(AppStatus.logging_error.value)
    else:
        rj.set_request_logging_status(AppStatus.logging_error.value)

    resp = rj.get_json()

    return resp


@app.post("/createneworder")
@log_request
@token_required
async def create_new_order(request: Request,
                           logger: str = Query(None, include_in_schema=False),
                           ccmg_token: str = Header(default=None),
                           params: Optional[basemodel.createNewOrder] = None
                           ):
    start_time = time.time()

    # add logic for api processing here #
    rtn = applogic.createNewOrder(app, params).get()
    # end of section #

    end_time = time.time()

    rj = ReturnJson()
    rj.set_fetch_time(end_time - start_time)
    rj.set_http_status(rtn['code'])
    rj.set_result_json(rtn['object'])

    if logger.result_code == AppStatus.success:
        rj.set_request_logging_status(AppStatus.success.value)

        resp_log = log_response(rj.serialize(), logger.result_obj)
        if resp_log.result_code == AppStatus.success:
            rj.set_response_logging_status(AppStatus.success.value)
        else:
            rj.set_response_logging_status(AppStatus.logging_error.value)
    else:
        rj.set_request_logging_status(AppStatus.logging_error.value)

    resp = rj.get_json()

    return resp


@app.post("/orderhistory")
@log_request
@token_required
async def order_history(request: Request,
                        logger: str = Query(None, include_in_schema=False),
                        ccmg_token: str = Header(default=None),
                        params: Optional[basemodel.orderhistory] = None
                        ):
    start_time = time.time()

    # add logic for api processing here #
    rtn = applogic.getOrderHistory(app,params).get()
    # end of section #

    end_time = time.time()

    rj = ReturnJson()
    rj.set_fetch_time(end_time - start_time)
    rj.set_http_status(rtn['code'])
    rj.set_result_json(rtn['object'])

    if logger.result_code == AppStatus.success:
        rj.set_request_logging_status(AppStatus.success.value)

        resp_log = log_response(rj.serialize(), logger.result_obj)
        if resp_log.result_code == AppStatus.success:
            rj.set_response_logging_status(AppStatus.success.value)
        else:
            rj.set_response_logging_status(AppStatus.logging_error.value)
    else:
        rj.set_request_logging_status(AppStatus.logging_error.value)

    resp = rj.get_json()

    return resp


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
