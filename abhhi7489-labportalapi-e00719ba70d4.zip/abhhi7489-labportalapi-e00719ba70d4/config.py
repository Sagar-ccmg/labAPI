aws_region = 'ap-south-1'
aws_console_url = 'https://041271707857.signin.aws.amazon.com/console'
cloudwatch_user_access_key = 'AKIAQTG74JDIW4C3X7N3'
cloudwatch_user_access_secret = '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'
cloudwatch_log_group_name = 'LabPortalLogs'
cloudwatch_log_stream_name_api = 'APILogs'
cloudwatch_log_stream_name_fe = 'FrontEndLogs'
cloudwatch_log_retention_window_days = 365

db_host = 'ccmg-dev-collance.c9u4fryy0ibx.ap-south-1.rds.amazonaws.com'
db_port = 3306
db_user = 'dev_lab1'
db_password = 'Collance@123'

kc_realm_name = 'B2B'
kc_server = 'http://43.204.34.109'
kc_port = 8080
kc_realm_token_url = '{}:{}/realms/{}/protocol/openid-connect/token'.format(kc_server, kc_port, kc_realm_name)
kc_add_user_url = '{}:{}/admin/realms/{}/users'.format(kc_server, kc_port, kc_realm_name)
kc_bot_admin = 'service_admin'
kc_bot_admin_passwd = 'CCMG@2023'
kc_client = 'lab-app'
kc_client_secret = 'IxQdVgTQuQv9edEKWpXK73oHHKac6AZh'
