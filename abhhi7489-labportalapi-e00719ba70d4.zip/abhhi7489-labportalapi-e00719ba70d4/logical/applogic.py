import json

from fastapi.encoders import jsonable_encoder

from logical import database
from models.enums import HTTPStatus
from models.result import Result


def getLookups(app, params):
    res = Result()

    try:
        db_obj = database.connectToDB(app).get()
        if db_obj['code'] == HTTPStatus.success:
            cursor = db_obj['object'][0]
            db = db_obj['object'][1]
            query = 'call `sp_getLookupValues`("{}")'.format("" if params is None else params)
            res = database.runQueryMultiResultset(cursor, query)
            if res.result_code == HTTPStatus.success:
                res.result_obj = res.result_obj[0]
                res.set(HTTPStatus.success, res.result_obj)
            cursor.close()

        else:
            res = db_obj

        db.close()

    except Exception as e:
        res.set(HTTPStatus.error, e)
    finally:
        return res


def getClientLogo(app, clientid):
    res = Result()

    try:
        db_obj = database.connectToDB(app).get()
        if db_obj['code'] == HTTPStatus.success:
            cursor = db_obj['object'][0]
            db = db_obj['object'][1]
            query = "call sp_getClientLogo('{}')".format(clientid)
            res = database.runQueryMultiResultset(cursor, query)
            res.result_obj = [
                {"client_id": x['clientID'], "clientpdfname": x['pdfPrintName'], "logo_string": x['logoImage']} for x in
                res.result_obj[0]]

            cursor.close()

        else:
            res = db_obj

        db.close()

    except Exception as e:
        res.set(HTTPStatus.error, e)
    finally:
        return res


def getAccountProjects(app):
    res = Result()

    try:
        db_obj = database.connectToDB(app).get()
        if db_obj['code'] == HTTPStatus.success:
            cursor = db_obj['object'][0]
            db = db_obj['object'][1]
            query = 'call sp_get_account_projects()'
            res = database.runQueryMultiResultset(cursor, query)
            res.result_obj = [x["json_data"] for x in res.result_obj[0]]
            res.result_obj = [eval(x) for x in res.result_obj]

            cursor.close()

        else:
            res = db_obj

        db.close()

    except Exception as e:
        res.set(HTTPStatus.error, e)
    finally:
        return res


def getStateCityList(app):
    res = Result()
    try:
        db_obj = database.connectToDB(app).get()
        if db_obj['code'] == HTTPStatus.success:
            cursor = db_obj['object'][0]
            db = db_obj['object'][1]
            query = 'call sp_getstatecity_list()'
            res = database.runQueryMultiResultset(cursor, query)
            if res.result_code == HTTPStatus.success:
                res.result_obj = [x["stateJson"] for x in res.result_obj[0]]
                res.result_obj = [eval(x) for x in res.result_obj]

            cursor.close()

        else:
            res = db_obj

        db.close()

    except Exception as e:
        res.set(HTTPStatus.error, e)
    finally:
        return res


def getMemberList(app, params):
    res = Result()
    account_name, project_name, city, state, zip, health_plan, pcp_name, member_filter_json, gap_name, existing_order, paging_json, \
        start_date, end_date, visit_status, visit_start_date, visit_end_date, fullfillment_mode = dict(params).values()

    # converting  JSON object to Dict
    # paging_json =dict(paging_json)
    # member_filter_json = jsonable_encoder(member_filter)
    # paging_json={"paging_json":jsonable_encoder(paging)}
    member_filter_json = {"member_filter": [x.serialize() for x in member_filter_json]}
    # member_filter = json.dumps(member_filter)
    paging_json = {"paging_json": paging_json.serialize()}
    try:
        db_obj = database.connectToDB(app).get()
        if db_obj['code'] == HTTPStatus.success:
            cursor = db_obj['object'][0]
            db = db_obj['object'][1]
            query = "call sp_getMembersList('{account_name}','{project_name}','{city}','{state}','{zip}','{health_plan}','{pcp_name}','{member_filter_json}','{gap_name}',{existing_order},'{paging_json}','{start_date}','{end_date}',{visit_status},'{visit_start_date}','{visit_end_date}',{fullfillment_mode})".format(
                account_name=account_name, project_name=project_name, city=city, state=state, zip=zip,
                health_plan=health_plan, pcp_name=pcp_name,member_filter_json=json.dumps(member_filter_json), gap_name=gap_name,
                existing_order=existing_order,
                paging_json=json.dumps(paging_json), start_date=start_date, end_date=end_date,
                visit_status=visit_status, visit_start_date=visit_start_date, visit_end_date=visit_end_date,
                fullfillment_mode=fullfillment_mode)
            res = database.runQueryMultiResultset(cursor, query)
            res.result_obj = [json.loads(x["resultCol"]) for x in res.result_obj[1]]
            # res.result_obj=[eval(x) for x in res.result_obj]

            cursor.close()
        # """""""
        else:
            res = db_obj

        db.close()

    except Exception as e:
        res.set(HTTPStatus.error, e)
    finally:
        return res


def get_matching_PCP_list(app, params):
    res = Result()
    params = str(params)
    try:
        db_obj = database.connectToDB(app).get()
        if db_obj['code'] == HTTPStatus.success:
            cursor = db_obj['object'][0]
            db = db_obj['object'][1]
            query = "call get_matching_PCP_list('{}')".format(params)
            res = database.runQueryMultiResultset(cursor, query)
            res.result_obj = [
                {"providerId": x['providerId'], "pcp_name": x['pcpName']} for x in res.result_obj[0]]
            cursor.close()

        else:
            res = db_obj

        db.close()

    except Exception as e:
        res.set(HTTPStatus.error, e)
    finally:
        return res


def sp_getVisitStatusME(app, params=''):
    res = Result()
    params = str(params)
    try:
        db_obj = database.connectToDB(app).get()
        if db_obj['code'] == HTTPStatus.success:
            cursor = db_obj['object'][0]
            db = db_obj['object'][1]
            query = "call sp_getVisitStatusME()"
            res = database.runQueryMultiResultset(cursor, query)
            res.result_obj = [
                {"lookupId": x['lookupId'], "lookupType": x['lookupType'], "lookupValue": x['lookupValue']} for x in
                res.result_obj[0]]
            cursor.close()

        else:
            res = db_obj

        db.close()

    except Exception as e:
        res.set(HTTPStatus.error, e)
    finally:
        return res


def physicianWorkLoad(app):
    res = Result()
    try:
        db_obj = database.connectToDB(app).get()
        if db_obj['code'] == HTTPStatus.success:
            cursor = db_obj['object'][0]
            db = db_obj['object'][1]
            query = "call sp_getPhysician()"
            res = database.runQueryMultiResultset(cursor, query)
            work_load = [{"state": x["licensedStates"], "orders_count": x["order_count"]} for x in res.result_obj[0]]
            res.result_obj = [
                {"physician_id": x['physicianId'], "physician_name": x['physician_name'], "work_load": work_load}
                for x in res.result_obj[0]]
            cursor.close()

        else:
            res = db_obj

        db.close()

    except Exception as e:
        res.set(HTTPStatus.error, e)
    finally:
        return res


def createNewOrder(app, params):
    res = Result()
    # account_id, member_list, panel_id, lob_id, physician_id, created_by, fullfillmode = dict(params).values()
    member_list, fullfillmode, panel_id, lob_id, ordering_physician_id, user_id = dict(params).values()
    member_list = {"member_list": jsonable_encoder(member_list)}

    try:
        db_obj = database.connectToDB(app).get()
        if db_obj['code'] == HTTPStatus.success:
            cursor = db_obj['object'][0]
            db = db_obj['object'][1]
            query = """call sp_createOrder('{member_list}','{panel_id}','{lob_id}',{ordering_physician_id},'{fullfillmode}','{user_id}')""".format(
                member_list=json.dumps(member_list), panel_id=panel_id, lob_id=lob_id,
                ordering_physician_id=ordering_physician_id, user_id=user_id, fullfillmode=fullfillmode)
            res = database.runQueryMultiResultset(cursor, query)
            res.result_obj = [json.loads(x["memberJson"]) for x in res.result_obj[0]]
            cursor.close()

        else:
            res = db_obj

        db.close()

    except Exception as e:
        res.set(HTTPStatus.error, e)
    finally:
        return res


def validationOfOrder(app):
    res = Result()

    try:
        db_obj = database.connectToDB(app).get()
        if db_obj['code'] == HTTPStatus.success:
            cursor = db_obj['object'][0]
            db = db_obj['object'][1]
            query = "call sp_getOrderHistory()"
            res = database.runQueryMultiResultset(cursor, query)
            cursor.close()

        else:
            res = db_obj

        db.close()

    except Exception as e:
        res.set(HTTPStatus.error, e)
    finally:
        return res


def getOrderHistory(app, params):
    res = Result()
    order_start_date, order_end_date, ordering_physician_id, account_id, project_id, health_id, pcp_id, panel_ids, order_status, test_status = dict(
        params).values()

    try:
        db_obj = database.connectToDB(app).get()
        if db_obj['code'] == HTTPStatus.success:
            cursor = db_obj['object'][0]
            db = db_obj['object'][1]
            query = "call sp_getOrderHistory('{order_start_date}','{order_end_date}','{ordering_physician_id}','{account_id}','{project_id}','{health_id}','{pcp_id}','{panel_ids}','{order_status}','{test_status}')".formate(
                order_start_date=order_start_date, order_end_date=order_end_date,
                ordering_physician_id=ordering_physician_id, account_id=account_id, project_id=project_id,
                health_id=health_id, pcp_id=pcp_id, panel_ids=panel_ids, order_status=order_status,
                test_status=test_status)
            res = database.runQueryMultiResultset(cursor, query)


            cursor.close()

        else:
            res = db_obj

        db.close()

    except Exception as e:
        res.set(HTTPStatus.error, e)
    finally:
        return res
