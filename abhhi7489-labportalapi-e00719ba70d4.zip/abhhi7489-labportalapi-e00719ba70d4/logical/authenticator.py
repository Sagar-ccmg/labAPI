from functools import wraps
from fastapi import Request, HTTPException
from models.enums import HTTPStatus

def token_required(f):
    @wraps(f)
    def authenticate(request: Request, *args, **kwargs):
        token = None
        # ensure the jwt-token is passed with the headers
        if 'ccmg-token' in request.headers:
            token = request.headers['ccmg-token']
        if not token: # throw error if no token provided
            raise HTTPException(status_code=HTTPStatus.unauthorized.value[0], detail="Token not sent")
        try:
           # if token is provided verify token
           #  raise Exception
            pass
        except:
            raise HTTPException(status_code=HTTPStatus.unauthorized.value[0], detail="Invalid token sent")

        return f(request, *args, **kwargs)
    return authenticate

