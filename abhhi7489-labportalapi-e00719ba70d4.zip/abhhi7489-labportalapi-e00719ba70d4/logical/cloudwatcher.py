import config
import boto3
import time
import json
from models.enums import *
from models.exceptions import *

class CloudWatcher:
    __client = None
    __log_group = False
    __log_stream_api = False
    __log_stream_fe = None

    @staticmethod
    def send_api_log(message):
        if CloudWatcher.__client is None:
            try:
                CloudWatcher.__client = boto3.client('logs',
                                      region_name=config.aws_region,
                                      aws_access_key_id=config.cloudwatch_user_access_key,
                                      aws_secret_access_key=config.cloudwatch_user_access_secret
                                      )
            except Exception as e:
                raise AWSConnectionException(e)

        if not CloudWatcher.__log_group :
            try:
                _ = CloudWatcher.__client.create_log_group(
                    logGroupName=config.cloudwatch_log_group_name
                )

                _ = CloudWatcher.__client.put_retention_policy(
                    logGroupName=config.cloudwatch_log_group_name,
                    retentionInDays=config.cloudwatch_log_retention_window_days
                )

                CloudWatcher.__log_group = True

            except CloudWatcher.__client.exceptions.ResourceAlreadyExistsException:
                pass
            except Exception as e:
                raise AWSCloudWatchLogGroupException(e)

        if not CloudWatcher.__log_stream_api:
            try:
                _ = CloudWatcher.__client.create_log_stream(
                            logGroupName=config.cloudwatch_log_group_name,
                            logStreamName=config.cloudwatch_log_stream_name_api
                        )

                CloudWatcher.__log_stream_api = True

            except CloudWatcher.__client.exceptions.ResourceAlreadyExistsException:
                pass
            except Exception as e:
                raise AWSCloudWatchLogStreamException(e)

        try:
            _ = CloudWatcher.__client.put_log_events(
                logGroupName=config.cloudwatch_log_group_name,
                logStreamName=config.cloudwatch_log_stream_name_api,
                logEvents=[
                    {
                        'message': json.dumps(message),
                        'timestamp': int(round(time.time()*1000))
                    }
                ]
            )
        except Exception as e:
            raise AWSLogException(e)

