import MySQLdb
import config
from models.exceptions import *
from models.result import Result
from models.enums import *


# create connection to database
def connectToDB(app, dbname="lab_integration"):
    try:
        res = Result()
        db = MySQLdb.connect(host=config.db_host,
                             port=config.db_port,
                             user=config.db_user,
                             passwd=config.db_password,
                             db=dbname,
                             connect_timeout=120
                             )
        cursor = db.cursor()

        res.set(HTTPStatus.success,  [cursor, db])
        return res
    except Exception as e:
        raise DBConnectionException(e)

def runQueryMultiResultset(cursor, query):
    res = Result()

    try:
        records = []
        cursor.execute(query)

        # for first resultset
        columns = cursor.description
        resultset = [{columns[index][0]: column for index, column in enumerate(value)} for value in cursor.fetchall()]
        records.append(resultset)

        # for consecutive resultsets
        while(cursor.nextset()):
            columns = cursor.description
            resultset = [{columns[index][0]: column for index, column in enumerate(value)} for value in cursor.fetchall()]
            if len(resultset)>0:
                records.append(resultset)

        res.set(HTTPStatus.success, records)
        
        return res

    except Exception as e:
        raise DBCursorFetchException(e)



