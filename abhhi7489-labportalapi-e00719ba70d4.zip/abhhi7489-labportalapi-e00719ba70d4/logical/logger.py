from functools import wraps
from fastapi import Request
from logical import cloudwatcher
from models.result import Result
from models.enums import AppStatus
import uuid

def log_request(func):
    @wraps(func)
    async def wrapper(request: Request, *args, **kwargs):
        res = Result()
        request_id = str(uuid.uuid4())

        message = {
            'host': str(request.base_url.hostname),
            'args': str(kwargs),
            'client': str(request.client.host),
            'port': str(request.client.port),
            'path_params': str(request.path_params),
            'query_params': str(request.query_params),
            'scope': str(request.scope),
            'is_secure': str(request.url.is_secure),
            'resource_path': str(request.url.path),
            'username': str(request.url.username),
            'query': str(request.url.query),
            'header': str(request.headers)
        }

        try:
            cloudwatcher.CloudWatcher.send_api_log({'request_id': request_id, 'request': message})
            res.set(AppStatus.success, request_id)

        except Exception as e:
            res.set(AppStatus.logging_error, e)

        finally:
            kwargs['logger'] = res

        return await func(request, *args, **kwargs)

    return wrapper

def log_response(resp, request_id):
    res = Result()
    try:
        cloudwatcher.CloudWatcher.send_api_log({'request_id': request_id, 'response': resp})
        res.set(AppStatus.success, request_id)

    except Exception as e:
        res.set(AppStatus.logging_error, e)

    finally:
        return res