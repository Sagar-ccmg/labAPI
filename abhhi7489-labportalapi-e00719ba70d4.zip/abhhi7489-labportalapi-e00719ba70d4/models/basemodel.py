from typing import Union, List

from pydantic import BaseModel


class MemberFilter(BaseModel):
    member_id: str
    account_id: Union[str, None] = None
    project_id: Union[str, None] = None
    kit_id: Union[str, None] = None

    def serialize(self):
        return {
            'member_id': self.member_id,
            'accountid': self.account_id,
            'projectid': self.project_id,
            'kit_id': self.kit_id
        }


class ColOrder(BaseModel):
    col_order: int
    col_name: str
    col_dir: str

    def serialize(self):
        return {
            'col_order': self.col_order,
            'col_name': self.col_name,
            'col_dir': self.col_dir
        }


class PagingJson(BaseModel):
    limit: int
    offset: int
    order: List[Union[ColOrder, None]] = None

    def serialize(self):
        return {
            'limit': self.limit,
            'offset': self.offset,
            'order': [x.serialize() for x in self.order]
        }


class MemberOrders(BaseModel):
    order_id: str
    order_date: str
    order_status: str


class FilterMemberRequest(BaseModel):
    account_id: str
    project_id: Union[str, None] = None
    city: Union[str, None] = None
    zip: Union[str, None] = None
    health_plan: Union[str, None] = None
    pcp_name: Union[str, None] = None
    existing_order: int
    start_date: Union[str, None] = None
    end_date: Union[str, None] = None
    member_filter: Union[MemberFilter, None] = None
    paging_json: PagingJson
    open_gaps_json: Union[List[int], None] = None


class MembersList(BaseModel):
    account_id: str
    project_id: Union[str, None] = None
    city: Union[str, None] = None
    state: Union[str, None] = None
    zip: Union[str, None] = None
    health_plan: Union[str, None] = None
    pcp_name: Union[str, None] = None
    member_filter: List[Union[MemberFilter, None]] = None
    gaps_name: Union[str, None] = None
    existing_order: int
    paging_json: Union[PagingJson, None] = None
    order_start_date: Union[str, None] = None
    order_end_date: Union[str, None] = None
    visit_status: int
    visit_start_date: Union[str, None] = None
    visit_end_date: Union[str, None] = None
    fulfillment_mode: int

    def serialize(self):
        return {
            'account_id': self.account_id,
            'project_id': self.project_id,
            'city': self.city,
            'state': self.state,
            'zip': self.zip,
            'health_plan': self.health_plan,
            'pcp_name': self.pcp_name,
            'member_filter_json': [x.serialize() for x in self.member_filter_json],
            'open_gaps_json': self.open_gaps_json,
            'existing_order': self.existing_order,
            'paging_json': [x.serialize() for x in self.paging_json],
            'start_date': self.start_date,
            'end_date': self.end_date,
            'visit_status': self.visit_status,
            'visit_start_date': self.visit_start_date,
            'visit_end_date': self.visit_end_date,
            'fulfillment_mode': self.fulfillment_mode
        }


class NewOrderMemberList(BaseModel):
    account_id: str
    project_id: Union[str, None] = None
    member_id: Union[str, None] = None
    kit_id: Union[str, None] = None


class createNewOrder(BaseModel):
    member_list: List[Union[NewOrderMemberList, None]] = None
    fullfillment_mode: Union[int, None] = None
    panel_id: Union[int, None] = None
    lob_id: Union[int, None] = None
    ordering_physican_id: Union[str, None] = None
    user_id: Union[str, None] = None


class orderhistory(BaseModel):
    order_start_date: Union[str, None] = None
    order_end_date: Union[str, None] = None
    ordering_physician_id: Union[str, None] = None
    account_id: Union[str, None] = None
    project_id: Union[str, None] = None
    healthplan_id: Union[str, None] = None
    pcp_id: Union[str, None] = None
    panel_id: Union[str, None] = None
    order_status: Union[str, None] = None
    test_status: Union[str, None] = None
