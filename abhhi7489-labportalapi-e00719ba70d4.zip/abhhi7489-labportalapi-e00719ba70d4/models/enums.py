from enum import Enum

class ExceptionMessage(Enum):
    aws_connecion_error = 'Error in connecting to AWS resources'
    aws_cloudwatch_loggroup_exception = 'Error in creating application events log group'
    aws_cloudwatch_logstream_exception = 'Error in creating application events log stream'
    aws_cloudwatch_log_exception = 'Error in sending application events log'

    db_connection_error = 'Error in connecting to host database'
    db_cursor_fetch_error = 'Error in fetching results from database'


class HTTPStatus(Enum):
    success = (200, 'success')
    created = (201, 'created')
    accepted = (202, 'accepted')
    no_content = (204, 'no content')
    bad_request = (400, 'bad_request')
    unauthorized = (401, 'unauthorized request')
    not_found = (404, 'resource not found')
    conflict = (409, 'duplicate conflict')
    error = (500, 'application error occured')


class AppStatus(Enum):
    success = {'code': 200, 'message': 'success'}
    logging_error = {'code': 900, 'message': 'error in logging request'}

class APIModules(Enum):
    place_order = ''




