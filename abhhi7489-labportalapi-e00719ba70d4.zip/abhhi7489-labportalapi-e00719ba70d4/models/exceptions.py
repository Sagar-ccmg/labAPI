from models.enums import ExceptionMessage

class AWSConnectionException(Exception):
    def __init__(self, obj, message=ExceptionMessage.aws_connecion_error):
        self.object = obj
        self.message = message
        super().__init__(self.message)

class AWSCloudWatchLogGroupException(Exception):
    def __init__(self, obj, message=ExceptionMessage.aws_cloudwatch_loggroup_exception):
        self.object = obj
        self.message = message
        super().__init__(self.message)

class AWSCloudWatchLogStreamException(Exception):
    def __init__(self, obj, message=ExceptionMessage.aws_cloudwatch_logstream_exception):
        self.object = obj
        self.message = message
        super().__init__(self.message)

class AWSLogException(Exception):
    def __init__(self, obj, message=ExceptionMessage.aws_cloudwatch_log_exception):
        self.object = obj
        self.message = message
        super().__init__(self.message)

class DBConnectionException(Exception):
    def __init__(self, obj, message=ExceptionMessage.db_connection_error):
        self.object = obj
        self.message = message
        super().__init__(self.message)

class DBCursorFetchException(Exception):
    def __init__(self, obj, message=ExceptionMessage.db_cursor_fetch_error):
        self.object = obj
        self.message = message
        super().__init__(self.message)