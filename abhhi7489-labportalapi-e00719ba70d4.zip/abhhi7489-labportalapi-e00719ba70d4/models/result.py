class Result:
    def __init__(self):
        self.result_code = 0
        self.result_obj = {}

    def get(self):
        return {'code': self.result_code, 'object': self.result_obj}

    def set(self, result_code, result_obj):
        self.result_code = result_code
        self.result_obj = result_obj