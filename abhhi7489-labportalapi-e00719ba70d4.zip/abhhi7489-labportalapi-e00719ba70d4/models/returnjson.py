from models.enums import HTTPStatus, AppStatus
from fastapi.responses import JSONResponse

class ReturnJson:
    def __init__(self):
        self.http_status = None
        self.status = None
        self.fetch_time = None
        self.result_json = None
        self.request_logging_status = None
        self.response_logging_status = None

    def set_http_status(self, status):
        self.http_status = status.value[0]
        self.status = status.value[1]

    def set_result_json(self, rjson):
        self.result_json = rjson

    def set_fetch_time(self, ftime):
        self.fetch_time = ftime

    def set_request_logging_status(self, req_status):
        self.request_logging_status = req_status

    def set_response_logging_status(self, resp_status):
        self.response_logging_status = resp_status

    def get_json(self):
        return JSONResponse(status_code=self.http_status,
                            content={
                                'status': self.status,
                                'fetch_time': self.fetch_time,
                                'result': self.result_json,
                                'request_logging': self.request_logging_status,
                                'response_logging': self.response_logging_status
                            })
    def serialize(self):
        return {'status_code':self.http_status,
                    'content': {
                        'status': self.status,
                        'fetch_time': self.fetch_time,
                        'result': self.result_json,
                        'request_logging': self.request_logging_status
                    }
                }